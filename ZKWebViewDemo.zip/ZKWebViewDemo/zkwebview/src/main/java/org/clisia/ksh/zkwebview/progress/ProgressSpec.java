package org.clisia.ksh.zkwebview.progress;

public interface ProgressSpec {


    void reset();

    void setProgress(int newProgress);


}
