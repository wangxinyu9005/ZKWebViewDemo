package org.clisia.ksh.zkwebview.file;


public interface FileUploadPop<T> {

    T pop();


}
