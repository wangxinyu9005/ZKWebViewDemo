package org.clisia.ksh.zkwebview.progress;

import android.widget.FrameLayout;


public interface LayoutParamsOffer<T extends FrameLayout.LayoutParams> {

    T offerLayoutParams();

}
