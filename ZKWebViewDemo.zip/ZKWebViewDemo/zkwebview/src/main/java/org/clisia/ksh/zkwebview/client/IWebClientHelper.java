package org.clisia.ksh.zkwebview.client;

/**
 * 服务 WebViewClient ，处理一些常用固定的业务的
 */

public interface IWebClientHelper {
}
