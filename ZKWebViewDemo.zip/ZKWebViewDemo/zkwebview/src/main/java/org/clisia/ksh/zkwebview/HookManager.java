package org.clisia.ksh.zkwebview;



public class HookManager {


    public static SuperWebX5 hookSuperWeb(SuperWebX5 superWebX5, SuperWebX5.SuperBuilder superBuilder) {
        return superWebX5;
    }

    public static SuperWebX5 hookSuperWeb(SuperWebX5 superWebX5, SuperWebX5.SuperBuilderFragment superBuilder) {
        return superWebX5;
    }

}
