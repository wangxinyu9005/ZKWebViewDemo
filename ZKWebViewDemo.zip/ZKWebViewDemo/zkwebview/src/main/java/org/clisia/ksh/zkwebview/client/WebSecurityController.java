package org.clisia.ksh.zkwebview.client;

public interface WebSecurityController<T> {

    void check(T t);

}
