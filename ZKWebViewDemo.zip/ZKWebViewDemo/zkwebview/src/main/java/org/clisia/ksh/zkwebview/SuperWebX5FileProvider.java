package org.clisia.ksh.zkwebview;

import android.support.v4.content.FileProvider;


/**
 * 内容提供者
 */
public class SuperWebX5FileProvider extends FileProvider {

}
