package org.clisia.ksh.zkwebview.progress;


public interface BaseProgressSpec extends ProgressSpec {
    void show();

    void hide();
}
