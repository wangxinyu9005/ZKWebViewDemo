package org.clisia.ksh.zkwebview;


public interface SuperWebX5Compat {
}
