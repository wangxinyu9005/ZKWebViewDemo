package org.clisia.ksh.zkwebview.js;


public class JsInterfaceObjectException extends RuntimeException {
    JsInterfaceObjectException(String msg){
        super(msg);
    }
}
