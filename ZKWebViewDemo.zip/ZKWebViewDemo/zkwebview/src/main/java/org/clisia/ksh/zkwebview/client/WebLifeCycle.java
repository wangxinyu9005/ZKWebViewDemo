package org.clisia.ksh.zkwebview.client;

public interface WebLifeCycle {


    void onResume();
    void onPause();
    void onDestroy();


}
