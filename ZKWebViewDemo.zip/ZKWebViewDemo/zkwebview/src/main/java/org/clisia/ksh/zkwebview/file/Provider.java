package org.clisia.ksh.zkwebview.file;

public interface Provider<T> {


   T provide();
}
