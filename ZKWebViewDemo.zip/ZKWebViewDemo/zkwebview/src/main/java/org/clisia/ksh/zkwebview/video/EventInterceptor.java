package org.clisia.ksh.zkwebview.video;


/**
 * 事件拦截接口
 */
public interface EventInterceptor {

    boolean event();

}
